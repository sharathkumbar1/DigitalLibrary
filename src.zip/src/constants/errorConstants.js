export const SUCCESS_ON_SAVE = 'A verification link has been sent to your email.'
export const SUCCESS_ON_RESET = "Password has been reset, please login using latest password"
export const SUCCESS_ON_ACCOUNT_VERIFY = "Your account has been verified, please login using your credentials"