import React from "react";

const AppImage = () => {
  return (
    <div className="hero-image">
     
      <div className="hero-text">
        <p style={{ fontSize: 50 }}>Digital Library</p>
      </div>
    </div>
  );
};

export default AppImage;
