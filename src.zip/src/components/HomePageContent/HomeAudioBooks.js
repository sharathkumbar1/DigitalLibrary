
import React, {useState, useEffect} from 'react';
import { useDispatch, useSelector } from "react-redux";
 import { makeStyles } from "@material-ui/core/styles";


import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';

import Button from '@material-ui/core/Button';

import { Link, useHistory, NavLink} from "react-router-dom";

import GridList from '@material-ui/core/GridList';
import GridListTile from '@material-ui/core/GridListTile';
import GridListTileBar from '@material-ui/core/GridListTileBar';
import axios from 'axios'



const useStyles = makeStyles((theme) => ({
    root: {
      backgroundColor: theme.palette.background.paper,
      width: 2000,
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'space-around',
      overflow: 'hidden',
      backgroundColor: theme.palette.background.paper,
    },
    root: {
      flexGrow: 1,
    },
    paper: {
      padding: theme.spacing(2),
      textAlign: 'center',
      color: theme.palette.text.secondary,
    },
    title: {
        fontSize: 12,
      },
      pos: {
        marginBottom: 12,
      },
      card:{
        minWidth: 100,
        direction: 'row',
        float: 'left',
  width: 50,
  padding: 0
        },
    media: {
            height: 140,
          },
          image: {
            width: 128,
            height: 128,
          },

    fonts:{
        fontSize:18,
        fontStyle: 'italic',
        align: 'left',
        fontWeight : 'bold',
       color:'darkgreen'
    },
    gridList: {
        width: 400,
        height: 450,
        
      },
      icon: {
        color: 'rgba(255, 255, 255, 0.54)',
      },
  }));
 const HomeAudioBooks = ()=>{
    const classes = useStyles();
    const [homeAudioBooksRA, setHomeAudioBooksRA] = useState([]);
    const [homeAudioBooksBM, setHomeAudioBooksBM] = useState([]);
    const [homeAudioBooksRV, setHomeAudioBooksRV] = useState([]);
    const [error, setError] = useState(null);
    let history = useHistory();
    let dispatch = useDispatch();
    const [filterPDF, setFilterPDF] = useState(false);

     
    useEffect(() => {
       fetch("http://ec2-13-232-236-83.ap-south-1.compute.amazonaws.com:8080/home_page_books?user_id=23&per_page=1&book_type=AUDIO_BOOK")
          .then(res => res.json())
          .then(
            (result) => {
              
                    setHomeAudioBooksRA(result.recently_added_books);
                    setHomeAudioBooksBM(result.bookmarked_books);
                    setHomeAudioBooksRV(result.recently_viewed_books);
                    console.log(result)
                
                
               },
            (error) => {
               setError(error);
            }
          )
          
      }, [])



      const handleRoute = (route) => {
        history.push(`${route}`);
      };

   const recentlyAddedAudioBooks = () => {
    handleRoute("/recently_added_audiobooks")
   }

   

   const bookMarkedAudio = () => {
    handleRoute("/book_marked_audiobooks")
}

const recentlyViewed= () => {
    // axios.get('http://ec2-13-232-236-83.ap-south-1.compute.amazonaws.com:8080/users/23/recently_viewed_books').then(
    //     (res) => {
    //         var RVB = res.data
    //         console.log(RVB)
    //     }
    // )
    handleRoute("/viewed_audiobooks")
}

// const readClicked = (pdfLink) => {
//     dispatch(setPdfURL(pdfLink));
//     console.log("book opened")
//     history.push("/er");

//   };



       return (

              <div className={classes.root}>
                 
      <Grid container spacing={3}>
      
        <Grid item xs={12} >
        <Paper className={classes.paper} textAlign='left'>
           <text className={classes.fonts}> Recently Added Audio Books</text><br/>
           <Link>
            <Button variant="contained" color="secondary" onClick={recentlyAddedAudioBooks}>
        more >
      </Button>
      </Link>
        
        </Paper>
        </Grid>
        


<GridList cellHeight={180} className={classes.gridList}>

        {homeAudioBooksRA.map((item) => (
        <GridListTile>
            <img src={item.thumbnail_url} alt={item.title} />
            <GridListTileBar
              title={item.title}
              subtitle={<span>by: {item.author}</span>}
            />
          </GridListTile>
        ))}

      </GridList>


        <Grid item xs={12}>
          <Paper className={classes.paper}>
              <text className={classes.fonts}>Book Marked Audio Books</text> <br/>
              <Link>
               <Button variant="contained" color="secondary" onClick={bookMarkedAudio}>more > 
               </Button>
               </Link>
            
          </Paper>

          <GridList cellHeight={180} className={classes.gridList}>

        {homeAudioBooksBM.map((item) => (
        <GridListTile>
            <img src={item.book.thumbnail_url} alt={item.title} />
            <GridListTileBar
              title={item.book.title}
              subtitle={<span>by: {item.book.author}</span>}
            />
          </GridListTile>
        ))}

      </GridList>


        </Grid>
        <Grid item xs={12}>
          <Paper className={classes.paper}>
          <text className={classes.fonts}>Recently Viewed Audio Books</text> <br/>
              <Link>
               <Button variant="contained" color="secondary" onClick={recentlyViewed}>more > 
               </Button>
               </Link>
          </Paper>
          <GridList cellHeight={180} className={classes.gridList}>

        {homeAudioBooksRV.map((item) => (
        <GridListTile>
            <img src={item.book.thumbnail_url} alt={item.title} />
            <GridListTileBar
              title={item.book.title}
              subtitle={<span>by: {item.book.author}</span>}
            />
          </GridListTile>
        ))}

      </GridList>
        </Grid>
        </Grid>
    </div> 
          
        );
      }
    




  export default HomeAudioBooks





   
       
   

