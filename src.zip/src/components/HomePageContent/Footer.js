import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import BottomNavigation from '@material-ui/core/BottomNavigation';
import BottomNavigationAction from '@material-ui/core/BottomNavigationAction';
import HomeIcon from '@material-ui/icons/Home';
import SearchIcon from '@material-ui/icons/Search';
import BookmarkIcon from '@material-ui/icons/Bookmark';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import { useHistory} from "react-router-dom";
import { Router } from 'react-router-dom/cjs/react-router-dom.min';
import HomePageContent from "../HomePageContent/HomePageContent"
import { withRouter } from 'react-router-dom';


const useStyles = makeStyles({
  root: {
    width: 390,
  },
});

 function Footer(props) {
  const classes = useStyles();
  const [value, setValue] = React.useState(0);
  const history = useHistory();

  const handleRoute = (route) => {
    props.history.push(`${route}`);
    
  };

 const goToHome = () => {
   handleRoute("/");
 }
  

  return (
    <BottomNavigation
      value={value}
      onChange={(event, newValue) => {
        setValue(newValue);
      }}
      showLabels
      className={classes.root}
    >
      <BottomNavigationAction   label="Home" icon={<HomeIcon />} onClick={goToHome} />
      <BottomNavigationAction   label="Search" icon={<SearchIcon />} />
      <BottomNavigationAction  label="Saved" icon={<BookmarkIcon />} />
      <BottomNavigationAction label="My Acc" icon={<AccountCircleIcon/>} />
    </BottomNavigation>
  );
}

export default (Footer)
